local api = require("transfromage")
local client = api.client:new()

client:once("ready", function()
	client:connect("Username#0000", "password")
end)

client:start("Owner ID", "API Token")