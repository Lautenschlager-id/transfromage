local api = require("transfromage")
local client = api.client()

client:once("ready", function()
	client:connect("Username#0000", "password")
end)

client:start("PLAYER_ID", "API_TOKEN")